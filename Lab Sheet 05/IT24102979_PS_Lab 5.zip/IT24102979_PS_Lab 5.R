##Part 1
##Setting the directory
setwd("D:\\SLIIT\\Lab\\PS\\Lab 5")

##importing the data set
Delivery_Times<-read.table("Exercise - Lab 05.txt", header = TRUE)


##view the file
fix(Delivery_Times)


##Rename the variable
names(Delivery_Times)<-("Delivery_Times_m")

##Attach the file in to R
attach(Delivery_Times)

##Part 2 - Histogram

histogram<-hist(Delivery_Times_m, main = "Histogram for Delivery Times in minutes", breaks = seq(20,70, length = 10), right = TRUE)

##part 4 - Draw a cummulative frequency polygon
##assign class limits
breaks <- round(histogram$breaks)

##assign class frequency
freq <- histogram$counts

##assign mid points
mids <- histogram$mids

##cumulative frequency
cum.freq <- cumsum(freq)

##creating null variable
new <- c()

##cumulative frequencies in oder to get the ogive
for (i in 1: length(breaks)){
  if(i == 1){
    new[i] = 0
    
  }else{
    new[i] = cum.freq[i-1]
  }
}

##draw cummulative frequency polygon in a new plot 
plot(breaks, new, type = 'o', main = "cummulative frequency polygon for Delivery Times",
     xlab = "Delivery Times Minutes", ylab = "Cumulative Frequency", ylim = c(0, max(cum.freq)))

##obtain upper limit
cbind(Upper = breaks, cum.freq = new)