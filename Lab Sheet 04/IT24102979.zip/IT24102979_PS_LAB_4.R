setwd("C:/UsersIT24102979/Desktop/IT24102979")

##1

branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")

fix(branch_data)

attach(branch_data)

##3
boxplot(X1, main = "Box plot for Sales", outline = TRUE, outpch = 8, horizontal = TRUE)
boxplot(X2, main = "Box plot for Advertising", outline = TRUE, outpch = 8 , horizontal = TRUE)
boxplot(X3, main = "Box plot for Years", outline = TRUE, outpch = 8 , horizontal = TRUE)

##4

summary(branch_data$Advertising_X2)
fivenum(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)


##5
advertisin_summery <- function(x){
  fivenum(x)
  IQR(x)
}
advertisin_summery(branch_data$Advertising_X2)




